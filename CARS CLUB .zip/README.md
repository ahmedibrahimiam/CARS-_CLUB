Cars Club Backend - Final Package

How to run (local):
1. npm install
2. npm run seed    # seeds admin (Ahmed) + parts + brands + car
3. npm run dev     # or npm start

Seeded admin credentials:
  name: Ahmed
  email: ahmedibrahimiam@gmail.com
  password: iaam20032020

Notes:
- .env file included for convenience; for production set env vars on Vercel.
- Images are in public/images/ and seed uses relative URLs like /images/fuel_pump.jpeg
